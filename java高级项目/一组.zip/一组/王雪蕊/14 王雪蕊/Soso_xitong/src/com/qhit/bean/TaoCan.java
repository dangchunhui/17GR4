package com.qhit.bean;

public abstract class TaoCan {
	private double price;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	//��ʾ�ײ���Ϣ
	public abstract void show();

}
