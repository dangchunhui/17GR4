package com.qhit.bean;

import com.qhit.service.ShangWang;

public class NetTaoCan extends TaoCan implements ShangWang {
	private int liuliang=3;
	
	public NetTaoCan(){
		super.setPrice(68);
	}

	public int getLiuliang() {
		
		return liuliang;
	}

	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	
	public void show(){
		System.out.println("(｡･∀･)ﾉﾞ嗨，我是网虫套餐，我有"+this.liuliang+"流量");
	}

}
