package com.qhit.bean;


import com.qhit.service.SendDuanXin;
import com.qhit.service.ShangWang;
import com.qhit.service.Talk;

public  class SuperTaoCan extends TaoCan implements Talk,SendDuanXin,ShangWang {
	private int time=200;
	private int duanxin=50;
	private int liuliang=1;
	
	public SuperTaoCan(){
		super.setPrice(78);
	}
	
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getDuanxin() {
		return duanxin;
	}
	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}
	public int getLiuliang() {
		return liuliang;
	}
	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	

	public void show(){
		System.out.println("�٣����ǳ����ײ�Ŷ������"+this.time+"����ʱ��"+this.duanxin+"������"+this.liuliang+"G����");
	}

	@Override
	public void dadianhua(int time, ShouJiCard sjc) {
		// TODO Auto-generated method stub
		
	}
}
