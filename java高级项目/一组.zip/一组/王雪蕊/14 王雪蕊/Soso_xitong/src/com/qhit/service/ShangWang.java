package com.qhit.service;

public interface ShangWang {

}
