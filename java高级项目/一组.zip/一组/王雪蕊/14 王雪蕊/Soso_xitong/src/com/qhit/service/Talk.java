package com.qhit.service;

import com.qhit.bean.ShouJiCard;

public interface Talk {
	
	void dadianhua(int time,ShouJiCard sjc);

}
