package com.qhit.bean;

public class ShouJiCard {
	private String shoujihao;//�ֻ���
	private String name;//�û���
	private String password;//����
	private TaoCan tc;//�ײͶ���
	private double yue;//���
	
	private double shiyongqian;//����
	private int thtime;//ʵ��ͨ��
	private int sendduanxin;//ʵ��ʹ�ö���
	private int liuliang;//ʵ��ʹ������
	
	
	public double getShiyongqian() {
		return shiyongqian;
	}
	public void setShiyongqian(double shiyongqian) {
		this.shiyongqian = shiyongqian;
	}
	public int getThtime() {
		return thtime;
	}
	public void setThtime(int thtime) {
		this.thtime = thtime;
	}
	public int getSendduanxin() {
		return sendduanxin;
	}
	public void setSendduanxin(int sendduanxin) {
		this.sendduanxin = sendduanxin;
	}
	public int getLiuliang() {
		return liuliang;
	}
	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	public String getShoujihao() {
		return shoujihao;
	}
	public void setShoujihao(String shoujihao) {
		this.shoujihao = shoujihao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public TaoCan getTc() {
		return tc;
	}
	public void setTc(TaoCan tc) {
		this.tc = tc;
	}
	public double getYue() {
		return yue;
	}
	public void setYue(double yue) {
		this.yue = yue;
	}
	
	
	

}
