/**
 * 
 */
package com.qhit.service;

import com.qhit.bean.ShoujiCard;

/**
 * @author admin
 * 2018年5月4日
 */
//通话
public interface Talk {
	    //定义一个打电话的功能
		void  dadianhua(int time,ShoujiCard sjc);

}
