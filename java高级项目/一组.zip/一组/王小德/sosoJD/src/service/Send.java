package service;

import bean.MobileCard;

//���ŷ���
public interface Send {

	public void duanxin(int number,MobileCard sjk);
}
