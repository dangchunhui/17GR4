package bean;

public class Changjing {

	String leixing ;
	String Disprition;
	int shuju;
	public Changjing (String leixing ,String Disprition,int shuju){
		this.Disprition=Disprition;this.leixing=leixing;this.shuju=shuju;
	}
	public String getLeixing() {
		return leixing;
	}
	public void setLeixing(String leixing) {
		this.leixing = leixing;
	}
	public String getDisprition() {
		return Disprition;
	}
	public void setDisprition(String disprition) {
		Disprition = disprition;
	}
	public int getShuju() {
		return shuju;
	}
	public void setShuju(int shuju) {
		this.shuju = shuju;
	}
	
}
