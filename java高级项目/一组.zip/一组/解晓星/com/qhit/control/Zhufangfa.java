package com.qhit.control;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;



import com.qhit.bean.Chaorentaocan;
import com.qhit.bean.Hualaotaocan;
import com.qhit.bean.Kabao;
import com.qhit.bean.Kaxinxi;
import com.qhit.bean.Wangchongtaocan;
import com.qhit.dao.CardDao;
import com.qhit.util.Gongjvbao;

public class Zhufangfa {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Gongjvbao gjb=new Gongjvbao();
		CardDao cd=new CardDao();
		boolean yy=true;
		while (yy) {
			System.out.println("***********************欢迎使用***********************");
			System.out.println("1.用户登陆\t2.用户注册");
			int sk=sc.nextInt();
			switch (sk) {
				case 1:
					System.out.println("用户登陆");
					boolean dl=true;
					while(dl){
						System.out.println("输入账号");
						String zhanghao=sc.next();
						System.out.println("输入密码");
						String password=sc.next();
						Set<String> st=cd.mp.keySet();
						
						Iterator<String>it=st.iterator();
						while (it.hasNext()){
							String shouji=it.next();
							System.out.println(shouji);
							String mima=cd.mp.get(shouji).getPassword();
							if (shouji.equals(zhanghao)) {
								if (password.equals(mima)) {
									System.out.println("进入其中");
									System.out.println("******************************欢迎"+shouji+"登陆移动客户端******************************");
									System.out.println("\t******************************请选择菜单******************************");
									System.out.println("1.充钱吧小伙\t2.充钱吧小伙\t3.充钱吧小伙\t4.充钱吧小伙\t5.充钱吧小伙");
									int caidan=sc.nextInt();
									switch (caidan) {
									case 1:
										System.out.println("1.充钱吧小伙");
										
										break;
									case 2:
										System.out.println("2.充钱吧小伙");
										
										break;
									case 3:
										System.out.println("3.充钱吧小伙");
										
										break;
									case 4:
										System.out.println("4.充钱吧小伙");
										
										break;
									case 5:
										System.out.println("5.充钱吧小伙");
										
										break;
									case 6:
										System.out.println("6.充钱吧小伙");
										
										break;
									default:
										break;
									}

									System.out.println("是否要退出");
									dl=false;
								}else{
									System.out.println("密码不正确");
								}
							}else{
								System.out.println("未查询到此账号");
							}
						}
					}
					
				
					break;
				case 2:
					System.out.println("用户注册");
					String [] hm=gjb.haoma(9);
					for (int i = 0; i < hm.length; i++) {
						if (i%3==0) {
							System.out.println();
						}
						System.out.print((i+1)+"."+hm[i]+"\t");
					}
					System.out.println();
					System.out.println("请选择手机号（1~9）");
					int xuanka=sc.nextInt();
					String shoujihao=hm[xuanka-1];//选卡
					System.out.println("1.话痨套餐2.网虫套餐3.超人套餐（请选择）");
					int xtc=sc.nextInt();
					Kabao kb = null;
					switch (xtc) {
					case 1:
						kb=new Chaorentaocan();
						kb.show();
						break;
					case 2:
						kb=new Wangchongtaocan();
						kb.show();
						break;
					case 3:
						kb=new Hualaotaocan();
						kb.show();
						break;
					default:
						break;
					}
					System.out.println("请输入姓名");
					String name=sc.next();
					System.out.println("请输入密码");
					String mima=sc.next();
					System.out.print("预存话费充值，请输入您要充值的金额:");
					int hf=sc.nextInt();
					while (hf<kb.getPrice()) {
						System.out.println("不足抵消本月月租，重新输入");
						hf=sc.nextInt();
					}
					Kaxinxi k=new Kaxinxi();
					k.setName(name);
					k.setPassword(mima);
					k.setShoujihao(shoujihao);
					k.setTc(kb);
					k.setYue(hf-kb.getPrice());
					cd.add(k);
					break;
				case 3:
					
					break;
				case 4:
					
					break;
				case 5:
					
					break;
				case 6:
					
					break;
				default:
					System.out.println("输入错误");
					break;
			}
			
		}
		
	}
}
