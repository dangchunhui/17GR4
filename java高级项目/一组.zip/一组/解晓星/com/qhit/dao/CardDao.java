package com.qhit.dao;

import java.util.HashMap;
import java.util.Map;

import com.qhit.bean.Kaxinxi;

public class CardDao {
	public Map<String, Kaxinxi>mp=new HashMap<String, Kaxinxi>();
	public void add(Kaxinxi kxx){
		mp.put(kxx.getShoujihao(), kxx);
		System.out.println("注册成功");
		System.out.println("手机号为："+kxx.getShoujihao());
		kxx.getTc().show();
	}
}
