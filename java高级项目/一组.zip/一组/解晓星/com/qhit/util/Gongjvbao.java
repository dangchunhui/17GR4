package com.qhit.util;

import java.util.Random;

public class Gongjvbao {
	public String [] haoma(int a){
		Random rd=new Random();
		String []kk=new String[a];
		for (int i = 0; i < kk.length; i++) {
			String [] tous={"155","136","187"};
			String numb="";
			for (int j = 0; j < 8; j++) {
				numb+=rd.nextInt(10);
			}
			int xh=rd.nextInt(tous.length);
			String hao=tous[xh]+numb;
			kk[i]=hao;
		}
		
		return kk;
		
	}
}
