package com.qhit.bean;

public class Kaxinxi {
	private String Shoujihao;//手机号	
	private String name;//用户名
	private String password;//密码
	private Kabao tc;//套餐
	private double yue;//余额
	public String getShoujihao() {
		return Shoujihao;
	}
	public void setShoujihao(String shoujihao) {
		Shoujihao = shoujihao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Kabao getTc() {
		return tc;
	}
	public void setTc(Kabao tc) {
		this.tc = tc;
	}
	public double getYue() {
		return yue;
	}
	public void setYue(double yue) {
		this.yue = yue;
	}
}
