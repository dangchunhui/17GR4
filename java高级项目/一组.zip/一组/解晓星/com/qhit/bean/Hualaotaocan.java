package com.qhit.bean;

public class Hualaotaocan extends Kabao{
	private int time=500;
	
	public Hualaotaocan(){
		super.setPrice(58);
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("话痨套餐");
		System.out.println("月租"+super.getPrice());
		
	}
}
