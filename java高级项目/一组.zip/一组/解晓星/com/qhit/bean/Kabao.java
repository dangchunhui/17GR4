package com.qhit.bean;

public abstract class Kabao {
	private int price;
	
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public abstract void show();
}
