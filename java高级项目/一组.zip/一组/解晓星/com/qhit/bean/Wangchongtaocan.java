package com.qhit.bean;

public class Wangchongtaocan extends Kabao{
	private int liuliang;
	public Wangchongtaocan(){
		super.setPrice(68);
	}
	public int getLiuliang() {
		return liuliang;
	}
	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	@Override
	public void show() {
		System.out.println("网虫套餐");
		System.out.println("月租"+super.getPrice());
		
	}
	
}
