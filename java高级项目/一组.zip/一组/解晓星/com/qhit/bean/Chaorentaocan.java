package com.qhit.bean;

public class Chaorentaocan extends Kabao{
	private int liuliang;
	private int duanxin;
	private int tome;
	public Chaorentaocan(){
		super.setPrice(78);
	}
	
	public int getLiuliang() {
		return liuliang;
	}
	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	public int getDuanxin() {
		return duanxin;
	}
	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}
	public int getTome() {
		return tome;
	}
	public void setTome(int tome) {
		this.tome = tome;
	}
	@Override
	public void show() {
		System.out.println("超人套餐");
		System.out.println("月租"+super.getPrice());
	}
}
