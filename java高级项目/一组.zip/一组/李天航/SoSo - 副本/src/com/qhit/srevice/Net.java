/**
 * 
 */
package com.qhit.srevice;

/**
 * @author admin
 * 2018�?�?�?
 */
public interface Net {

}
