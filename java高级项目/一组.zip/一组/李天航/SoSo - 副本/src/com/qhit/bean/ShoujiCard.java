package com.qhit.bean;

public class ShoujiCard {
	private String shoujihao;
	private String name;
	private String password;
	private TaoCan tc;
	private double yue;
	public String getShoujihao() {
		return shoujihao;
	}
	public void setShoujihao(String shoujihao) {
		this.shoujihao = shoujihao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public TaoCan getTc() {
		return tc;
	}
	public void setTc(TaoCan tc) {
		this.tc = tc;
	}
	public double getYue() {
		return yue;
	}
	public void setYue(double yue) {
		this.yue = yue;
	}
	
	


}