package com.qhit.srevice;

public interface SendDuanxin {

}
