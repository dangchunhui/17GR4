package com.qhit.bean;

import com.qhit.service.Talk;
import com.qhit.srevice.SendDuanxin;


public class SuperTaoCan extends TaoCan implements Talk,SendDuanxin {
	private int time=500;
	private int duanxin=30;
	
	public SuperTaoCan(){
		super.setPrice(58);
	}
	

	public int getTime() {
		return time;
	}



	public void setTime(int time) {
		this.time = time;
	}



	public int getDuanxin() {
		return duanxin;
	}



	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}



	@Override
	public void show() {
		System.out.println("���ǻ����ײͣ���"+this.time+"����ͨ������"+this.duanxin+"����,�ײͷ���"+super.getPrice()+"Ԫ");
		
		
	}

}