/**
 * 
 */
package com.qhit.bean;


public class NetTaoCan extends TaoCan implements Net  {

	private int liulang=3;
	
   public NetTaoCan(){
	   
	   super.setPrice(68);
   }
	
	
	
	public int getLiulang() {
		return liulang;
	}
	public void setLiulang(int liulang) {
		this.liulang = liulang;
	}



	@Override
	public void show() {
		System.out.println("我是网虫套餐：有"+this.liulang+"GB����,套餐费用�?"+super.getPrice()+"�?");
		
	}

}
