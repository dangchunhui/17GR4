package com.qhit.bean;

public interface Net {

}
