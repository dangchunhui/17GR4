package com.qhit.service;

import com.qhit.bean.ShoujiCard;

public interface Net {

	  void shangwang(int liuliang,ShoujiCard sjc);
}
