package com.qhit.bean;

public class Changjing {
	
	String leixing;
	int  shuju;
	String disprition;
	public String getLeixing() {
		return leixing;
	}
	public void setLeixing(String leixing) {
		this.leixing = leixing;
	}
	public int getShuju() {
		return shuju;
	}
	public void setShuju(int shuju) {
		this.shuju = shuju;
	}
	public String getDisprition() {
		return disprition;
	}
	public void setDisprition(String disprition) {
		this.disprition = disprition;
	}
	


}
