/**
 * 
 */
package com.qhit.bean;

import com.qhit.service.Net;

/**
 * @author admin
 * 2018年5月4日
 */
public class NetTaoCan extends TaoCan implements Net  {

	private int liulang=3;
	
   public NetTaoCan(){
	   
	   super.setPrice(68);
   }
	
	
	
	public int getLiulang() {
		return liulang;
	}
	public void setLiulang(int liulang) {
		this.liulang = liulang;
	}



	@Override
	public void show() {
		System.out.println("我是网虫套餐：有"+this.liulang+"GB流量,套餐费用："+super.getPrice()+"元");
		
	}



	@Override
	public void shangwang(int liuliang, ShoujiCard sjc) {
		// TODO Auto-generated method stub
		
	}

}
