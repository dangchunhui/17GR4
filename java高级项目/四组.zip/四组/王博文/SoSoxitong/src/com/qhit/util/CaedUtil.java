package com.qhit.util;

import java.util.Random;

import com.qhit.bean.NetTaoCan;
import com.qhit.bean.SuperTaoCan;
import com.qhit.bean.TalkTaoCan;
import com.qhit.bean.TaoCan;

public class CaedUtil {

	//接受一个数字，返回对应大小的一个手机号数组
	public String[] gethaos(int a){
		String[] numbers=new String[a];
		String[] tou={"159","139","138","134"};
		Random rd=new Random();
		int c=0;
		int d=0;
		for (int i = 0; i < a; i++) {
			do {
				c=rd.nextInt(100000000);
			} while(c<10000000);
			
			//随机生成前三位
			for (int j = 0; j < tou.length; j++) {
				d=rd.nextInt(tou.length);													
			}
			numbers[i]=tou[d]+c;
		}		
						
	  return numbers;
	}
	//根据a选择对应的套餐对象
	
	public TaoCan getTaoCan(int a){
		TaoCan tc=null;
		
		if(a==1){
			tc=new TalkTaoCan();
		}else if(a==2){
			tc=new NetTaoCan();
		}else if(a==3){
			tc=new SuperTaoCan();
		}
		
		return tc;
	}
	
	
	
	
	
	
	
}
