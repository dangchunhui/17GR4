package com.qhit.bean;

public abstract class TaoCan {

	private double price;//月租 

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	//显示套餐信息
	public abstract void show();
	
	
}
