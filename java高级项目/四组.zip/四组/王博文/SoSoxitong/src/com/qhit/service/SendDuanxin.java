package com.qhit.service;

public class SendDuanxin {

}
