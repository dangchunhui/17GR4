package com.qhit.bean;

public class NetTaoCan extends TaoCan{

	private int luiliang=3;

	public NetTaoCan(){
		super.setPrice(68);
	}
	
	public int getLuiliang() {
		return luiliang;
	}

	public void setLuiliang(int luiliang) {
		this.luiliang = luiliang;
	}

	
	public void show() {
		System.out.println("网虫套餐：有"+this.luiliang+"GB流量/月,套餐费用"+super.getPrice()+"元/月");
		
	}

	
}
