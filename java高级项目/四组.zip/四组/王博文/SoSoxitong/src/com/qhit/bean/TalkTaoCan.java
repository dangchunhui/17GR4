package com.qhit.bean;

public class TalkTaoCan extends TaoCan{

	private int time=500;
	private int duanxin=30;
	
	public TalkTaoCan(){
		super.setPrice(58);
	}
	
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getDuanxin() {
		return duanxin;
	}

	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}

	public void show() {
		System.out.println("话唠套餐：有"+this.time+"分钟通话/月,有"+this.duanxin+"条短信/月,套餐费用"+super.getPrice()+"元/月");	
	}

}
