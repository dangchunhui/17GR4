package com.qhit.service;

public class Talk {

}
