/**
 * 
 */
package com.qhit.bean;

/**
 * @author admin
 * 2018年5月4日
 */
public class ShoujiCard {
	private String shoujihao;//手机号
	private String name;//用户名
	private String password;//密码
	private TaoCan tc;//套餐对象
	private double yue;//余额
	
	private double shiyongqian;//消费
	private int thtime;//实际通话
	private int sendduanxin;//实际使用多少短信
	private int swliulang;//使用多少流量
    private double chongzhi;//本月充值
	
    
    
	
	public double getChongzhi() {
		return chongzhi;
	}
	public void setChongzhi(double chongzhi) {
		this.chongzhi = chongzhi;
	}
	public double getShiyongqian() {
		return shiyongqian;
	}
	public void setShiyongqian(double shiyongqian) {
		this.shiyongqian = shiyongqian;
	}
	public int getThtime() {
		return thtime;
	}
	public void setThtime(int thtime) {
		this.thtime = thtime;
	}
	public int getSendduanxin() {
		return sendduanxin;
	}
	public void setSendduanxin(int sendduanxin) {
		this.sendduanxin = sendduanxin;
	}
	public int getSwliulang() {
		return swliulang;
	}
	public void setSwliulang(int swliulang) {
		this.swliulang = swliulang;
	}
	public String getShoujihao() {
	
		return shoujihao;
	}
	public void setShoujihao(String shoujihao) {
		this.shoujihao = shoujihao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public TaoCan getTc() {
		return tc;
	}
	public void setTc(TaoCan tc) {
		this.tc = tc;
	}
	public double getYue() {
		return yue;
	}
	public void setYue(double yue) {
		this.yue = yue;
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
