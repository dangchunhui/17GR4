package com.qhit.bean;
import java.io.FileInputStream;
public class zfsm {
public  void main001() {
	try {
		FileInputStream inp=new FileInputStream("套餐资费说明.txt");
		byte[]b=new byte[512];
		int len=0;
		while((len=inp.read(b))!=-1){
			String ss=new String(b,"utf-8");
				System.out.println(ss);
				
			}
		inp.close();
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
