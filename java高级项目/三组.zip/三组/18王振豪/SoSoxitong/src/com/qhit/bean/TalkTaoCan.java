/**
 * 
 */
package com.qhit.bean;

import com.qhit.service.SendDuanxin;
import com.qhit.service.Talk;

/**
 * @author admin
 * 2018年5月4日
 */
public class TalkTaoCan extends TaoCan implements Talk,SendDuanxin {
    private int time=500;
    private int duanxin=30;
	
    //通过构造方法设置套餐费用
    public TalkTaoCan(){
    	super.setPrice(58);
    	
    }
    
    
  
	
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getDuanxin() {
		return duanxin;
	}

	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}



	@Override
	public void show() {
		System.out.println("我是话唠套餐：有"+this.time+"分钟通话，有"+this.duanxin+"短信,套餐费用："+super.getPrice()+"元");
		
	}




	@Override
	public void faduanxian(int duanxin, ShoujiCard sjc) {
		if(this.duanxin-duanxin>=0){
			sjc.setSendduanxin(sjc.getSendduanxin()+duanxin);
			this.duanxin=this.duanxin-duanxin;
		}else{
			double duanxinfei=  (duanxin-this.duanxin)*0.1;
			sjc.setShiyongqian(sjc.getShiyongqian()+duanxinfei);
			sjc.setSendduanxin(sjc.getSendduanxin()+duanxin);
			this.duanxin=0;
			sjc.setYue(sjc.getYue()-duanxinfei);
		}
		
		
		
		
		
	}




	@Override
	public void dadianhua(int time, ShoujiCard sjc) {
		 //如果进入if 证明免费通话没有使用完。不产生费用
		if(this.time-time>=0){
			//设置实际通话时间 获取上次时间，加上本次时间
			sjc.setThtime(sjc.getThtime()+time);
			//更新剩余免费通话
			this.time=this.time-time;
			
		}else{
		   //免费通话不足后产生的费用
			double xiaofei=  (time-this.time)*0.2;
			//更新消费 获取上次消费+本次消费 
			sjc.setShiyongqian(sjc.getShiyongqian()+xiaofei);
		     //实际通话时间
			sjc.setThtime(sjc.getThtime()+time);
			//免费通话使用完，清除免费通话
			this.time=0;
			//更新余额。 新的余额=上次余额-本次通话费用
			sjc.setYue(sjc.getYue()-xiaofei);
			
			
		}
		
	}








}
