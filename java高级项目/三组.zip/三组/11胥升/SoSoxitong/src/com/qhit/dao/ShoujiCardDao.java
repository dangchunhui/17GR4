package com.qhit.dao;

import java.util.HashMap;
import java.util.Map;
import com.qhit.bean.ShoujiCard;

public class ShoujiCardDao {
	
	Map<String,ShoujiCard> mp=new HashMap<String,ShoujiCard>();
	//添加手机卡
	
	public void add(ShoujiCard sjc){
		
		mp.put(sjc.getShoujihao(), sjc);
		System.out.println("注册成功！");
		System.out.println("卡号："+sjc.getShoujihao());
		System.out.println("用户名："+sjc.getName());
		sjc.getTc().show();
		System.out.println("余额："+sjc.getYue()+"元");
		
	}
	
}
