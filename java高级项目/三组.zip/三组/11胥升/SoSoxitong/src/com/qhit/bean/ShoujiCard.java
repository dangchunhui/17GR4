package com.qhit.bean;

public class ShoujiCard {

	private String shoujihao;//手机号
	private String name;//用户名
	private String password;//密码
	private TaoCan tc;//套餐对象
	private double yue;//余额
	
	
	public String getShoujihao() {
		return shoujihao;
	}
	public void setShoujihao(String shoujihao) {
		this.shoujihao = shoujihao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public TaoCan getTc() {
		return tc;
	}
	public void setTc(TaoCan tc) {
		this.tc = tc;
	}
	public double getYue() {
		return yue;
	}
	public void setYue(double yue) {
		this.yue = yue;
	}
	
	
}
