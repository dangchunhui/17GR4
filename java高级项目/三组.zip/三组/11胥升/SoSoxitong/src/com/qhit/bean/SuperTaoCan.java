package com.qhit.bean;

public class SuperTaoCan extends TaoCan{

	private int time=200;
	private int duanxin=50;
	private int luiliang=1;

	public SuperTaoCan(){
		super.setPrice(78);
	}
	
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public int getDuanxin() {
		return duanxin;
	}

	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}

	public int getLuiliang() {
		return luiliang;
	}

	public void setLuiliang(int luiliang) {
		this.luiliang = luiliang;
	}

	public void show() {
		System.out.println("超人套餐，有"+this.time+"分钟通话/月,有"+this.duanxin+"条短信/月,有"+this.luiliang+"GB流量/月,套餐费用"+super.getPrice()+"元/月");
		
	}

}
