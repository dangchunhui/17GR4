package com.qhit.contral;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Scanner;

import com.qhit.bean.ShoujiCard;
import com.qhit.bean.TaoCan;
import com.qhit.dao.ShoujiCardDao;
import com.qhit.util.CaedUtil;

public class SoSomsg {

	public static void main(String[] args) {
		
		System.out.println("*********欢迎使用嗖嗖移动业务大厅*********");
		System.out.println("1.用户登录   2.用户注册   3.使用嗖嗖   4.话费充值   5.资费说明    6.退出系统");
		
		Scanner sc=new Scanner(System.in);
		CaedUtil cu=new CaedUtil();
		ShoujiCardDao dao=new ShoujiCardDao();
		ShoujiCard sjk=new ShoujiCard();
		//获取选择的项
		
	while (true) {
		System.out.print("请选择：");
		int a=sc.nextInt();
		switch (a) {
		    case 1:{
		    	System.out.println("请输入手机号：");
		    	String user=sc.next();
		    	if(sjk.getShoujihao().equals(user)){
		    		System.out.println("请输入密码：");
			    	String passwords=sc.next();
			    	if(sjk.getPassword().equals(passwords)){
			    		System.out.println("******嗖嗖移动用户菜单*****");
						System.out.println("1.本月账单查询");
						System.out.println("2.套餐余量查询");
						System.out.println("3.打印消费清单");
						System.out.println("4.套餐变更");
						System.out.println("5.办理退网");
						System.out.println("请选择：");
						int aa=sc.nextInt();
						switch (aa) {
						  case 1:{	
							    System.out.println("姓名为："+sjk.getName());
								System.out.println("手机号为："+user);		
								System.out.println("资费为："+sjk.getTc().getPrice()+"元");
								System.out.println("剩余话费为："+sjk.getYue()+"元");							  
							break;
						  }
						  case 2:{
							break;
						  }
						  case 3:{
							break;
						  }
						  case 4:{
							break;
						  }
						  case 5:{
							break;
						  }																						
						}
											
					}else{
						System.out.println("对不起，您输入的密码有误！");
					}
		    	}else{
		    		System.out.println("对不起，没有此手机号!");
		    	}
		    	
			    //用户登录		    	
		    	break;
		    }
		    case 2:{
		    	//用户注册
		    	System.out.println("*****可选择的卡号*****");		    	
		    	String[] ka=cu.gethaos(9);
		    	for (int i = 0; i < 9; i++) {
		    		if(i%3==0){
						System.out.println("");
					}
					System.out.print((i+1)+"."+ka[i]+"\t");
				}
		    	
		    	System.out.println("");
		    	System.out.print("请选择手机号(1-9):");
		    	int b=sc.nextInt();
		    	System.out.println("1.话唠套餐   2.网虫套餐   3.超人套餐");
		    	int c=sc.nextInt();
		    	//得到套餐对象
		    	TaoCan tc=cu.getTaoCan(c);
		    	
		    	System.out.println("请输入姓名：");
		    	String name=sc.next();
		    	System.out.println("请输入密码：");
		    	String password=sc.next();
		    	System.out.println("请输入预存话费：");
		    	double hf=sc.nextDouble();
		    	
		    	while(hf<tc.getPrice()){
					System.out.println("您的预存话费金额不足，请重新缴费：");
					hf=sc.nextDouble();
				}
		    			    	
		    	sjk.setShoujihao(ka[b-1]);
		    	sjk.setName(name);
		    	sjk.setPassword(password);
		    	sjk.setTc(tc);
		    	sjk.setYue(hf-tc.getPrice());
		    	//存入map集合
		    	dao.add(sjk);
		    	
		    	break;
		    }
            case 3:{
		    	//使用
            	break;
		    }
            case 4:{
            	break;	
            }
            case 5:{
            	try {
        			
        			FileInputStream inp=new FileInputStream("套餐资费说明.txt");
        			byte[]b=new byte[1024];
        			int len=0;
        			while((len=inp.read(b))!=-1){
        			System.out.println(new String (b,0,len,"gbk"));
        				       			
        			}
        			inp.close();
        		} catch (Exception e) {
        			
        			e.printStackTrace();
        		}
            	break;
            }
            case 6:{           	
            	System.out.println("退出成功！");
            	break;
            }
                       
		default:
			System.out.println("对不起，没有此选项！");
			
		}
	}
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}
