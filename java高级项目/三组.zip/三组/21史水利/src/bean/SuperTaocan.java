package bean;

import service.Net;
import service.Send;
import service.Talk;

public class SuperTaocan extends Taocan implements Talk , Net , Send{

	private int time=500;
	private int liulang=3;
	private int duanxin=30;
	public SuperTaocan(){
		super.setPrice(78);
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getLiulang() {
		return liulang;
	}
	public void setLiulang(int liulang) {
		this.liulang = liulang;
	}
	public int getDuanxin() {
		return duanxin;
	}
	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("�����ײͣ���"+this.time+"ͨ�� ����"+this.duanxin+"�����ţ���"+this.liulang+"G�������ײͷ����ǣ�"+super.getPrice()+"Ԫ");
	}
	public void duanxin(int number, MobileCard sjk) {//ʹ�ö��ŷ���
		// TODO Auto-generated method stub
		
	}
	public void shangwang(int liuliang, MobileCard sjk) {//ʹ����������
		// TODO Auto-generated method stub
		
	}
	public void dadianhua(int time, MobileCard sjk) {//ʹ��ͨ������
		// TODO Auto-generated method stub
		
	}
	

	
}
