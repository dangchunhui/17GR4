package bean;

public class MobileCard {

	private String shoujihao;//�ֻ���
	private String name;//�û���
	private String password;//����
	private Taocan tc;//�ײͶ���
	private double yue;//���
	private double shiyongqian;//����
	private int shitime;//ʵ��ʱ��;
	private int sendduanxin;//ʵ��ʹ�ö���
	private int swliuliang;//ʵ��ʹ������	
	private double chongzhi;//���³�ֵ
	
	public double getChongzhi() {
		return chongzhi;
	}
	public void setChongzhi(double chongzhi) {
		this.chongzhi = chongzhi;
	}
	public String getShoujihao() {
		return shoujihao;
	}
	public double getShiyongqian() {
		return shiyongqian;
	}
	public void setShiyongqian(double shiyongqian) {
		this.shiyongqian = shiyongqian;
	}
	public int getShitime() {
		return shitime;
	}
	public void setShitime(int shitime) {
		this.shitime = shitime;
	}
	public int getSendduanxin() {
		return sendduanxin;
	}
	public void setSendduanxin(int sendduanxin) {
		this.sendduanxin = sendduanxin;
	}
	public int getSwliuliang() {
		return swliuliang;
	}
	public void setSwliuliang(int swliuliang) {
		this.swliuliang = swliuliang;
	}
	public void setShoujihao(String shoujihao) {
		this.shoujihao = shoujihao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Taocan getTc() {
		return tc;
	}
	public void setTc(Taocan tc) {
		this.tc = tc;
	}
	public double getYue() {
		return yue;
	}
	public void setYue(double yue) {
		this.yue = yue;
	}
	
}
