package bean;

import service.Net;

public class NetTaocan extends Taocan implements Net{

	private int liuliang=3;

	public NetTaocan(){
		super.setPrice(68);
	}
	public int getLiuliang() {
		return liuliang;
	}

	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}

	public void show() {
		// TODO Auto-generated method stub
		System.out.println("�����ײͣ���"+this.getLiuliang()+"G�������ײͷ����ǣ�"+super.getPrice()+"Ԫ");
	}
	public void shangwang(int liuliang, MobileCard sjk) {//ʹ����������
		// TODO Auto-generated method stub 
		
		
	}
	

	
	
	
	
}
