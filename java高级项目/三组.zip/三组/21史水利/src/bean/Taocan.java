package bean;

public abstract class Taocan {

	private double price;//���⣬
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public abstract void show();//��ʾ�ײ���Ϣ��

}
