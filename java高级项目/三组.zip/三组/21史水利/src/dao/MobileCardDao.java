package dao;

import java.util.HashMap;
import java.util.Map;

import bean.MobileCard;

public class MobileCardDao {

	Map<String , MobileCard> mp=new HashMap<String , MobileCard>();
	public void add(MobileCard sjk){
		mp.put(sjk.getShoujihao(),sjk);
		System.out.println("ע��ɹ������ţ�"+sjk.getShoujihao()+"�û���"+sjk.getName()+"���"+sjk.getYue()+"Ԫ");
		sjk.getTc().show();
		
	}

	public MobileCard chaz(String sjh){
		MobileCard k=null;
		k=mp.get(sjh);
		return k;
	}
	public void remove(String sjh){
		mp.remove(sjh);
		System.out.println("�����ɹ���");
	}

	
	
	
	
	
	
}
