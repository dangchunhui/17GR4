package com.qhit.service;

public interface SendDuanxin {

}
