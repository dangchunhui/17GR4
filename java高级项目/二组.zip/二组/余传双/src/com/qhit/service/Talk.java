package com.qhit.service;

public interface Talk {

}
