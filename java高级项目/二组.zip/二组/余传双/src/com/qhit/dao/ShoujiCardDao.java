package com.qhit.dao;

import java.util.HashMap;
import java.util.Map;

import com.qhit.bean.ShoujiCard;

public class ShoujiCardDao {
	Map<String, ShoujiCard>mp=new HashMap<String, ShoujiCard>();
	public void add(ShoujiCard sjk){
		//手机卡对象存入Map	集合
		mp.put(sjk.getShoujihao(), sjk);
		System.out.println("注册成功");
		System.out.println("卡号："+sjk.getShoujihao()+";用户名"+sjk.getName()+";当前余额"+sjk.getYue());
		sjk.getTc().show();
	}
}
