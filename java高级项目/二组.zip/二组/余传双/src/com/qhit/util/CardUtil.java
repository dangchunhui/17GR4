package com.qhit.util;
/*
 * 工具层
 * */


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Random;

import com.qhit.bean.NetTaoCan;
import com.qhit.bean.SuperTaoCan;
import com.qhit.bean.TalkTaoCan;
import com.qhit.bean.TaoCan;

public class CardUtil {
	/*
	 * 手机号码随机
	 * */
	//接收数组长度
	public String[] gethaos(int a){
		String [] number=new String[a];
		for (int c = 0; c < number.length; c++) {
			String [] tous={"135","136","138","150"};
			Random rd=new Random();//随机数类
			String nums="";
			for (int i = 0; i < 8; i++) {//通过循环得到8个数
				nums+=rd.nextInt(10);//随机一个1到10的整数
			}
			int xb=rd.nextInt(tous.length);//手机头三位  数组下标
			String haos=tous[xb]+nums;//将手机头三位与后八位结合
			number[c]=haos;
		}
		
		
		return number;
		
	}
	
	/*
	 * 套餐选择方法
	 * */
	public TaoCan getTaoCan(int a){
		TaoCan tc=null;
		if (a==1) {
			tc=new TalkTaoCan();
		}else if(a==2){
			tc=new NetTaoCan();
		}else if(a==3){
			tc=new SuperTaoCan();
		}else{
			
		}
		
		return tc;
		
	}
	
	
	public String zifei(){
		String aa="";
		try {
			FileInputStream fl=new FileInputStream("C:\\Users\\Lenovo\\Workspaces\\MyEclipse Professional\\Test1\\zifei");
			byte [] b=new byte[1024];
			int c=0;
			while ((c=fl.read(b))!=-1) {
				String ac=new String(b);
				aa=ac;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return aa;
	}
}
