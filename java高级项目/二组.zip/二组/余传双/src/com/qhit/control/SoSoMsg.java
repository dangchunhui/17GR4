package com.qhit.control;

import java.util.Scanner;

import com.qhit.bean.ShoujiCard;
import com.qhit.bean.TaoCan;
import com.qhit.dao.ShoujiCardDao;
import com.qhit.util.CardUtil;

public class SoSoMsg {
	public static void main(String[] args) {
		boolean y=true;
		while (y) {
			
			Scanner sc=new Scanner(System.in);
			CardUtil cu=new CardUtil();
			ShoujiCardDao dao=new ShoujiCardDao();
			System.out.println("*************欢迎使用*************");
			System.out.println("1.用户登录\t2.用户注册\t3.使用搜搜\t4.话费充值\t5.资费说明\t6.退出系统");
			System.out.print("选择");
			int a=sc.nextInt();
			if (a==1) {
				System.out.println("用户登录");
				
				
				
				
				
				
				
				
			}else if(a==2){
				System.out.println("用户注册");
				System.out.println("*************可选择卡号*************");
				String [] number=cu.gethaos(9);
				for (int i = 0; i < number.length; i++) {
					if (i%3==0) {
						System.out.println();
					}
					System.out.print((i+1)+"."+number[i]+"\t");
				}
				System.out.println();
				System.out.print("请选择手机号：");
				int kahao=sc.nextInt();
				String kaha=number[kahao-1];
				System.out.print("1.话痨套餐2.网虫套餐3.超人套餐（套餐选择）请选择输入序号：");
				int c=sc.nextInt();
				TaoCan tc=cu.getTaoCan(c);
				System.out.print("请输入姓名");
				String name=sc.next();
				System.out.print("请输入密码");
				String password=sc.next();
				System.out.print("请输入预存话费");
				double fh=sc.nextDouble();
				while (fh<tc.getPrice()) {
					System.out.println("您的预存话费不足本月消费");
					fh=sc.nextDouble();
				}
				
				ShoujiCard sjk=new ShoujiCard();
				sjk.setName(name);
				sjk.setPassword(password);
				sjk.setShoujihao(kaha);
				sjk.setTc(tc);
				sjk.setYue(fh-tc.getPrice());
				dao.add(sjk);
				
				
			}else if(a==3){
				System.out.println("使用搜搜");
				
			}else if(a==4){
				System.out.println("话费充值");
				
			}else if(a==5){
				System.out.println("资费说明");

				System.out.println(cu.zifei());
			}else if(a==6){
				System.out.println("退出系统");
				y=false;
			}else{
				
			}
		}
		System.out.println("程序结束");
		
	} 
}
