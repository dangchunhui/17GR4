package com.qhit.bean;
/*
 * 超人套餐
 * */
import com.qhit.service.Net;
import com.qhit.service.SendDuanxin;
import com.qhit.service.Talk;

public class SuperTaoCan extends TaoCan implements Net,Talk,SendDuanxin{//接入业务
	private int liuliang=1;
	private int duanxin=50;
	private int time=200;
	
	public SuperTaoCan(){
		super.setPrice(78);
	}
	
	public int getLiuliang() {
		return liuliang;
	}
	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	public int getDuanxin() {
		return duanxin;
	}
	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	@Override
	public void show() {
		System.out.println("我是超人套餐");
		System.out.println("通话时间："+this.time+"分钟;短信"+this.duanxin+"条;流量有"+this.liuliang+"G;月租"+super.getPrice()+"元/月");
		
	}
}
