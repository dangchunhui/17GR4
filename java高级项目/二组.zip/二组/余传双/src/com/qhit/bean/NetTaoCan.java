package com.qhit.bean;

import com.qhit.service.Net;

public class NetTaoCan extends TaoCan implements Net{//接入业务
	private int liuliang=3;
	
	public NetTaoCan(){
		super.setPrice(68);
	}
	
	public int getLiuliang() {
		return liuliang;
	}
	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}
	@Override
	public void show() {
		System.out.println("我是网虫套餐");
		System.out.println("流量有"+this.liuliang+"G;月租"+super.getPrice()+"元/月");
	}

}
