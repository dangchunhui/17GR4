package com.qhit.bean;
/*
 * 话唠套餐
 * */
import com.qhit.service.SendDuanxin;
import com.qhit.service.Talk;

public class TalkTaoCan extends TaoCan implements SendDuanxin,Talk{//接入业务
	private int time=500;
	private int duanxin=30;
	
	public TalkTaoCan(){
		super.setPrice(58);
	}
	
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getDuanxin() {
		return duanxin;
	}
	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}
	@Override
	public void show() {
		System.out.println("我是话唠套餐");
		System.out.println("通话时间："+this.time+";短信"+this.duanxin+"条;月租"+super.getPrice()+"元/月");
	}

}
