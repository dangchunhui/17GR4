package com.qhit.bean;

public abstract class TaoCan {
	private double price;//月租租费

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public abstract void show();//抽象类	 打印方法
}
