/**
 * 
 */
package com.qhit.service;

import com.qhit.bean.ShoujiCard;

/**
 * @author admin
 * 2018年5月4日
 */
public interface Net {

	  void shangwang(int liuliang,ShoujiCard sjc);
}
