/**
 * 
 */
package com.qhit.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.qhit.bean.ShoujiCard;

/**
 * @author admin
 * 2018年5月4日
 */
public class ShoujiCardDao {
	
	public  Map<String,ShoujiCard> mp=new HashMap<String,ShoujiCard>();
	public  ArrayList<ShoujiCard> al=new ArrayList<ShoujiCard>();
	
	//添加手机卡
	public void add(ShoujiCard sjc){
		//把手机卡对象存入到map集合里面，key手机号，value是手机卡对象
		mp.put(sjc.getShoujihao(),sjc);
		 al.add(sjc);
		//显示注册信息
		System.out.println("注册成功！卡号："+sjc.getShoujihao()+"用户名："+sjc.getName()+"余额："+sjc.getYue()+"元");
		//显示套餐信息
		sjc.getTc().show();
	}
	
	
	

}
