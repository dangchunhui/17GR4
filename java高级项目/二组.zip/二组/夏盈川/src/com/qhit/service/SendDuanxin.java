package com.qhit.service;

import com.qhit.bean.ShoujiCard;

public interface SendDuanxin {
    
	void faduanxian(int duanxin,ShoujiCard sjc);
	  
}
