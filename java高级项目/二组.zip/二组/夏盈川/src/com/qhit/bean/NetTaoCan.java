package com.qhit.bean;

import com.qhit.service.Net;

public class NetTaoCan extends TaoCan implements Net  {

	private int liulang=3;
	
   public NetTaoCan(){
	   
	   super.setPrice(68);
   }
	
	
	
	public int getLiulang() {
		return liulang;
	}
	public void setLiulang(int liulang) {
		this.liulang = liulang;
	}



	@Override
	public void show() {
		System.out.println("���������ײͣ���"+this.liulang+"GB����,�ײͷ��ã�"+super.getPrice()+"Ԫ");
		
	}



	@Override
	public void shangwang(int liuliang, ShoujiCard sjc) {
		// TODO Auto-generated method stub
		
	}

}
