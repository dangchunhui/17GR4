/**
 * 
 */
package com.qhit.util;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Random;

import com.qhit.bean.NetTaoCan;
import com.qhit.bean.SuperTaoCan;
import com.qhit.bean.TalkTaoCan;
import com.qhit.bean.TaoCan;

/**
 * @author admin
 * 2018年5月4日
 */
public class CardUtil {
	
	//接收一个数字，返回对应大小的一个手机号数组
	public String[] gethaos(int a){
		String[] numbers=new String[a];
		//定义所有可能使用的头
		String[] tous={"135","136","138","150"};
		//随机数类
		Random rd=new Random();
		
	  for(int c=0;c<numbers.length;c++ ){
		//随机生成后8位
		String nums="";
		for (int i = 0; i < 8; i++) {
			//通过循环，每次拼接一位，组成一个8位
			nums=	nums+rd.nextInt(10);
		}
		//随机头下标
	    int xb= rd.nextInt(tous.length);
	    //头+尾 生成手机号
	    String haos= tous[xb]+nums;
	    //通过循环把手机号放入要返回的数组里面
	    numbers[c]=haos;
	    
	  }	 
	     
		return numbers;
	}
	
	//根据a选择对应的套餐对象
	public TaoCan getTaoCan(int a){
		
		TaoCan tc=null;
		
		if(a==1){
		  tc= new TalkTaoCan();
		}else if(a==2){
		  tc= new NetTaoCan();	
			
		}else if(a==3){
		  tc=new SuperTaoCan();
		}
		
		return tc;
	}
	
		public  void zfcx() {
			try {
				FileInputStream inp=new FileInputStream("套餐资费说明.txt");
				byte[]b=new byte[512];
				int len=0;
				while((len=inp.read(b))!=-1){
					String ss=new String(b,"utf-8");
						System.out.println(ss);
						
					}
				inp.close();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	
	
	
	
	

}
