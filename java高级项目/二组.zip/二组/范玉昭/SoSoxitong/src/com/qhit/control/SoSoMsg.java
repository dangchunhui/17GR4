/**
 * 
 */
package com.qhit.control;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import com.qhit.bean.Changjing;
import com.qhit.bean.NetTaoCan;
import com.qhit.bean.ShoujiCard;
import com.qhit.bean.SuperTaoCan;
import com.qhit.bean.TalkTaoCan;
import com.qhit.bean.TaoCan;
import com.qhit.dao.ShoujiCardDao;
import com.qhit.util.CardUtil;


public class SoSoMsg {
	
	
	public static void main(String[] args) {
		
		Scanner  sc=new Scanner(System.in);
		CardUtil cu=  new CardUtil();
		ShoujiCardDao dao=  new ShoujiCardDao();
		
		boolean y=true;
	  //注册后自动循环
	  while(y){  
		
		System.out.println("*************欢迎使用嗖嗖移动业务大厅***************");
		System.out.println("1.用户登录   2.用户注册   3.使用嗖嗖   4.话费充值  5.资费说明  6.退出系统");
		System.out.print("请选择：");
		//获取选择的项
		int a=  sc.nextInt();
		
	   if(a==1){
	   //1.用户登录	
	   System.out.println("请输入手机号：");
	   String shoujihao=   sc.next();
	   System.out.println("请输入密码：");
	   String password= sc.next();
       //map {"1366666666"=sjk1，"1366666666"=sjk2，"1366666666"=sjk3，"1366666666"=sjk4}
	   //使用输入的手机号，在map里面去查找，看能否找到卡对象，然后再比较密码
	   ShoujiCard sjk2=  dao.mp.get(shoujihao);
	   if(sjk2!=null){
		   if(sjk2.getShoujihao().equals(shoujihao)&&sjk2.getPassword().equals(password)){
			
			  boolean bbb=true; 
			 
			  while(bbb){
			   System.out.println("*****嗖嗖移动用户菜单*****"); 
			   System.out.println("1.本月账单查询");
			   System.out.println("2.套餐余量查询");
			   System.out.println("3.打印消费详单");
			   System.out.println("4.套餐变更");
			   System.out.println("5.办理退网");
			   System.out.println("请选择(输入1~5选择功能，其他键返回上一级)：");
			   int d=   sc.nextInt();
			   
			   if(d==1){
				 //本月账单查询  
				 System.out.println("*****本月账单查询*******");
				 System.out.println("您的卡号："+sjk2.getShoujihao()+",当月账单：");
				 System.out.println("套餐资费："+sjk2.getTc().getPrice());
				 System.out.println("卡的消费："+sjk2.getShiyongqian());
				 System.out.println("合计消费："+(sjk2.getTc().getPrice()+sjk2.getShiyongqian()));
				 System.out.println("账户余额："+sjk2.getYue());
				 System.out.println("本月充值钱："+sjk2.getChongzhi());  
				 
			   }else if(d==2){
				   
				   System.out.println("*****套餐余量查询******");
				   System.out.println("您的卡号是"+sjk2.getShoujihao()+",套餐信息：");
				   if(sjk2.getTc() instanceof TalkTaoCan){
					   
					   TalkTaoCan tc=(TalkTaoCan)sjk2.getTc();
					   System.out.println("通话时间"+tc.getTime());
					   System.out.println("短信条数"+tc.getDuanxin());
					   System.out.println("已用通话："+sjk2.getThtime());
					   System.out.println("已用短信："+sjk2.getSendduanxin());
					   
					   
					   
					   
					   
				   }else if(sjk2.getTc() instanceof NetTaoCan){
					   
					   NetTaoCan nt=(NetTaoCan) sjk2.getTc();
					   System.out.println("上网流量："+nt.getLiulang());
					   
					   
					   
				   }else if(sjk2.getTc() instanceof SuperTaoCan){
					   SuperTaoCan stc=(SuperTaoCan) sjk2.getTc();
					   System.out.println("通话时间"+stc.getTime());
					   System.out.println("短信条数"+stc.getDuanxin());
					   System.out.println("上网流量："+stc.getLiuliang());
					   
					   
					   
				   }
				   
				   
			   }else if(d==3){
				   
			   }else if(d==4){
				   
				  System.out.println("*****套餐变更******");
				  System.out.println("1.话唠套餐  2.网虫套餐  3.超人套餐  请选择（序号）");
				  int f= sc.nextInt();
				  //获取新变更的套餐
				  TaoCan tc2= cu.getTaoCan(f);
				  
				 //通过获取卡对象里面的套餐里面月租和新选择套餐里面的月租对比，看是否需要变更
				if(sjk2.getTc().getPrice()==tc2.getPrice()){
					System.out.println("已经是当前套餐，不需要更换！");
					
				}else{
					//判断卡里面的余额大于新套餐费用吗
					if(sjk2.getYue()>tc2.getPrice()){
						sjk2.setTc(tc2);
						//变更套餐后扣除新套餐费用
						sjk2.setYue(sjk2.getYue()-tc2.getPrice());
						System.out.println("设置成功！当前套餐是：");
						sjk2.getTc().show();
						
					}else{
						System.out.println("余额不足以支付新套餐费用，请充值后再更换套餐");
					}
					
					
				}
				
				   
			   }else if(d==5){
				   System.out.println("****办理退网*****");
				   dao.mp.remove(sjk2.getShoujihao());
				   System.out.println("卡号"+sjk2.getShoujihao()+"办理退网成功");
				   //跳出子菜单的循环
				   bbb=false;
				   //跳出登录注册的循环 	
				   y=false;
			    	
				  
				   
			   }else{
				   //跳出子菜单循环
				   bbb=false;
				     
			   }
			   
			   
			 } //循环结束 
			   
			  
			   
	       }else {
			System.out.println("用户名或密码错误");
	    	   
		   }
		   
	   }else{
		   System.out.println("收入手机号不存在");
	   }
	   
	   
	 //登陆结束
	    	
	    }else if(a==2){
	      //  2.用户注册	
	    System.out.println("********可选择的卡号**********");
	    //获取手机号数组
	    String[] numbers =  cu.gethaos(9);
	    //显示手机号
	    for (int i = 0; i < numbers.length; i++) {
		   //控制3个换行
		   if(i%3==0){
			   System.out.println();
		   }
		   
		  System.out.print((i+1)+"."+numbers[i]+"\t");
		   
	    }
	    System.out.println();
	   System.out.print("请选择手机号（1-9）：");
	   //选择的手机号下标
	   int b=  sc.nextInt();
	   System.out.println("1.话唠套餐  2.网虫套餐  3.超人套餐，  请选择套餐(输入序号)：");
	   int c=  sc.nextInt();
	   //得到套餐对象
	   TaoCan tc=  cu.getTaoCan(c);
	   
	   System.out.print("请输入姓名：");
	   String name=  sc.next();
	   System.out.print("请输入密码：");
	   String password= sc.next();
	   System.out.println("请输入预存话费");
	   double hf=  sc.nextDouble();
	
	   //循环判断充值金额是否满足套餐金额  
	  while(hf<tc.getPrice()){
		   System.out.println("您预存话费金额不足以支付本月固定套餐资费，请重新充值：");
		   hf=  sc.nextDouble();
	  }
	  
	   
	   
	   ShoujiCard sjk=  new ShoujiCard(); 
	   sjk.setShoujihao(numbers[b-1]);
	   sjk.setName(name);
	   sjk.setPassword(password);
	   sjk.setTc(tc);
	   sjk.setYue(hf-tc.getPrice());
	   sjk.setChongzhi(hf);
	   //存入map集合里面
	    dao.add(sjk);
	 
	 	
	    //注册结束	
	    	
	    }else if(a==3){
	    	//使用soso
	    	
	    	
	    	System.out.println("请输入手机号：");
			String shoujihao=  sc.next();
			Random rd=new Random();
			
			ShoujiCard sjc=  dao.mp.get(shoujihao);
			if(sjc==null){
				System.out.println("此手机号，没有注册。");
			}else{
				
				 
				//得到套餐对象 看到的是父套餐，父套餐中存入的子套餐，找到对应的子套餐
				TaoCan tc=  sjc.getTc();
				//随机0到2 0打电话     1发短信      2上网
				int qq= 1;
				if(qq==0){
					//打电话
					if(tc instanceof TalkTaoCan){
						TalkTaoCan tt=(TalkTaoCan) tc;
						System.out.println("我是话唠套餐给奥巴马打300分钟电话。。。。");
						//调用打电话的方法
						tt.dadianhua(300, sjc);
						
						
						
					}else if(tc instanceof  SuperTaoCan){
						SuperTaoCan st=(SuperTaoCan) tc;
						System.out.println("我是超人套餐的我给奥巴马打300分钟电话。。。。");
						st.dadianhua(300, sjc);
						
						
					}else if(tc instanceof NetTaoCan){
						
						System.out.println("此套餐不支持通话。");
					}
					
					
					
					
				}else if(qq==1){
					//发短信
					
					//打电话
					if(tc instanceof TalkTaoCan){
						TalkTaoCan tt=(TalkTaoCan) tc;
						System.out.println("我是话唠套餐给拉登发20条短信，给我送个20个导弹。。。。");
						//调用打电话的方法
						tt.faduanxian(20, sjc);
						
						
					}else if(tc instanceof  SuperTaoCan){
						SuperTaoCan st=(SuperTaoCan) tc;
						System.out.println("我是超人套餐的我给奥巴马打300分钟电话。。。。");
						st.faduanxian(300, sjc);
						
						
					}else if(tc instanceof NetTaoCan){
						
						System.out.println("此套餐不支持发短信。");
					}
					
					
					
					
					
					
				}else if(qq==2){
					//上网
					
					
					
				}
				
				
				
				
				
				
				
				
				
				
			}
			
			
	    		
	    
	    	
	    	
	    	
	    	
	    	
	    }else if(a==4){
	    	//话费充值
	    System.out.println("请输入手机号：");
	    String shoujihao= sc.next();
	    	
	    ShoujiCard sjc3= dao.mp.get(shoujihao);
	    
	    System.out.println("请输入要充值金额：");
	    
	     double dd=  sc.nextDouble();
	     sjc3.setChongzhi(sjc3.getChongzhi()+dd);
	     
	     sjc3.setYue(sjc3.getYue()+dd);
	     System.out.println("充值成功！当前余额为："+sjc3.getYue());
	     
	    	
	    	
	    }else if(a==5){
	    	//套餐资费
	    	
	    	cu.zfcx();

	    }else if(a==6){
	    	y=false;
	    }else{
	    	System.out.println("没有此选项");
	    	
	    }
	
   
	  }//循环结束 
	  
	   System.out.println("程序结束！");
	  
	  
	}
}
