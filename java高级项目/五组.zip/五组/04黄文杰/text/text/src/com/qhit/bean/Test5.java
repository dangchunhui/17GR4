package com.qhit.bean;

public class Test5 {
	
	public static void main(String[] args) {
		boolean y=true;
		
		while(y){
			System.out.println("1.登陆，2.注册，3.使用嗖嗖");
			
			int a=1;
			if(a==1){
				//登陆
				   boolean bbb=true;
				  while(bbb){	
					System.out.println("1.打印月账单");
					System.out.println("2.套餐信息");
					System.out.println("3.注销");
					System.out.println("输入其他返回上层");
					int b=1;
					if(b==1){
						//1.打印月账单
						
					}else if(b==2){
						//2.套餐信息
					}else if(b==3){
						bbb=false;
						y=false;
					}else{
						//
						bbb=false;
					
					}
					
				  }//循环
				
				 
				
				
				
			}else if(a==2){
				//注册
			
				
				
			}else if(a==3){
				
			}
			
		}//循环结束
		
		System.out.println("程序结束！");
		
	}
	

}
