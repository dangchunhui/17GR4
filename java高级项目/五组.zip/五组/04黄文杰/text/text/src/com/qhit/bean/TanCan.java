package com.qhit.bean;

public class TanCan {

}
