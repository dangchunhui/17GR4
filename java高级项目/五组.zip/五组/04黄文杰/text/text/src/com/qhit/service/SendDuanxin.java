/**
 * 
 */
package com.qhit.service;

import com.qhit.bean.ShoujiCard;

/**
 * @author admin
 * 2018年5月4日
 */
public interface SendDuanxin {
    
	void faduanxian(int duanxin,ShoujiCard sjc);
	  
}
