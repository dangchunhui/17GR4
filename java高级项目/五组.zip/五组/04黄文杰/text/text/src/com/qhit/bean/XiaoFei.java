/**
 * 
 */
package com.qhit.bean;

/**
 * @author admin
 * 2018年5月11日
 */
public class XiaoFei {
	String shoujihao;//手机号
	String leixing;//类型 打电话  发短信  上网
	int shu;// 分钟  条数  GB
	public String getShoujihao() {
		return shoujihao;
	}
	public void setShoujihao(String shoujihao) {
		this.shoujihao = shoujihao;
	}
	public String getLeixing() {
		return leixing;
	}
	public void setLeixing(String leixing) {
		this.leixing = leixing;
	}
	public int getShu() {
		return shu;
	}
	public void setShu(int shu) {
		this.shu = shu;
	}
	
	
	
	

}
