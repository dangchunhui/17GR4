package com.qhit.service;

import com.qhit.bean.ShoujiCard;

public interface SendDuanxin {
	
	void Faduanxin(int duanxin,ShoujiCard sjk);

}
