package com.qhit.bean;

import com.qhit.service.Net;
import com.qhit.service.SendDuanxin;
import com.qhit.service.Talk;

public class SuperTaoCan extends TaoCan implements Talk,Net,SendDuanxin {
	private int time=200;
	private int duanxin=50;
	private int liuliang=1;
	
	public SuperTaoCan(){
		super.setPrice(78);
	}

	public int getTime() {
		return time;
	}



	public void setTime(int time) {
		this.time = time;
	}



	public int getDuanxin() {
		return duanxin;
	}



	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}



	public int getLiuliang() {
		return liuliang;
	}



	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}



	@Override
	public void show() {
		System.out.println("���ǳ����ײͣ���"+this.time+"����ͨ������"+this.duanxin+"����,��"+this.liuliang+"GB�������ײͷ���"+super.getPrice()+"Ԫ");

		
	}

	@Override
	public void Faduanxin(int duanxin, ShoujiCard sjk) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Shangwang(int liuliang, ShoujiCard sjk) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Dadianhua(int time, ShoujiCard sjk) {
		// TODO Auto-generated method stub
		
	}


}
