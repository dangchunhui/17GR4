package com.qhit.service;

import com.qhit.bean.ShoujiCard;

public interface Net {
	
	void Shangwang(int liuliang,ShoujiCard sjk);

}
