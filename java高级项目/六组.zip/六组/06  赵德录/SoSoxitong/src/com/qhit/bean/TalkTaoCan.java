package com.qhit.bean;

import com.qhit.service.SendDuanxin;
import com.qhit.service.Talk;

public class TalkTaoCan extends TaoCan implements Talk,SendDuanxin {
	private int time=500;
	private int duanxin=30;
	
	public TalkTaoCan(){
		super.setPrice(58);
	}
	

	public int getTime() {
		return time;
	}



	public void setTime(int time) {
		this.time = time;
	}



	public int getDuanxin() {
		return duanxin;
	}



	public void setDuanxin(int duanxin) {
		this.duanxin = duanxin;
	}



	@Override
	public void show() {
		System.out.println("���ǻ����ײͣ���"+this.time+"����ͨ������"+this.duanxin+"����,�ײͷ���"+super.getPrice()+"Ԫ");
		
		
	}


	@Override
	public void Faduanxin(int duanxin, ShoujiCard sjk) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void Dadianhua(int time, ShoujiCard sjk) {
		System.out.println("�ͳ�������50���ӵ绰");
		this.time= this.time-50;
		TaoCan tc=sjk.getTc();
		
		if(tc instanceof TalkTaoCan){
			TalkTaoCan tt=(TalkTaoCan) tc;
		
		}
	}

}
