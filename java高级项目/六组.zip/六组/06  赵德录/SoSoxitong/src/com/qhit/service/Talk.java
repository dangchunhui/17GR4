package com.qhit.service;

import com.qhit.bean.ShoujiCard;

public interface Talk {
	
	 void Dadianhua(int time,ShoujiCard sjk);

}
