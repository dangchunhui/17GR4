package com.qhit.util;

import java.util.Random;

import com.qhit.bean.NetTaoCan;
import com.qhit.bean.SuperTaoCan;
import com.qhit.bean.TalkTaoCan;
import com.qhit.bean.TaoCan;

public class CardUtil {
	
	public String[] gethaos(int a){
		String[] numbers=new String[a];
		String[] tous={"135","136","138","150"};
		//闅忔満鏁扮被
		Random rd=new Random();
		
		for (int c = 0; c < numbers.length; c++) {
			
		
		
		String nums="";
		for (int i = 0; i < 8; i++) {
			 nums = nums+rd.nextInt(10);

		}
		int xb= rd.nextInt(tous.length);
		String haos=tous[xb]+nums;
		
		numbers[c]=haos;
		}
		
		return numbers;
	}

	//鏍规嵁a閫夋嫨瀵瑰簲鐨勫椁愬璞�
	public TaoCan getTaoCan(int a){
		TaoCan tc=null;
		if(a==1){
			tc= new TalkTaoCan();
		}else if(a==2){
			tc=new NetTaoCan();
		}else if(a==3){
			tc= new SuperTaoCan();
		}

		return tc;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
