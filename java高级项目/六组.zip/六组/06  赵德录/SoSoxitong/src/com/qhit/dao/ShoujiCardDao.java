package com.qhit.dao;

import java.util.HashMap;
import java.util.Map;

import com.qhit.bean.ShoujiCard;

public class ShoujiCardDao {
	
	public Map<String,ShoujiCard> mp=new HashMap<String,ShoujiCard>();

	public void add(ShoujiCard sjc){
		
		mp.put(sjc.getShoujihao(), sjc);
		
		System.out.println("ע��ɹ�������:"+sjc.getShoujihao()+"�û���:"+sjc.getName()+"���:"+sjc.getYue()+"Ԫ");
		sjc.getTc().show();
		
		
	}
	
	
}
