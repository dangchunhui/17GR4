package com.qhit.bean;

import com.qhit.service.Net;

public abstract class NetTaoCan extends TaoCan implements Net {
	private int liuliang=3;
	
	public NetTaoCan(){
		super.setPrice(68);
	}

	public int getLiuliang() {
		return liuliang=3;
	}



	public void setLiuliang(int liuliang) {
		this.liuliang = liuliang;
	}



	@Override
	public void show() {
		System.out.println("���������ײͣ���"+this.liuliang+"GB����,�ײͷ���"+super.getPrice()+"Ԫ");
		
	}

	@Override
	public void Shangwang(int liuliang, ShoujiCard sjk) {
		// TODO Auto-generated method stub
		
	}

}
